<?php

return array(
	'contact_add' => array(),
	'contact_delete' => array(),
	'photo_add' => array(),
	'category_add' => array(),
	'group_add' => array(),
	'create_user_account' => array(),
	'search' => array(),
	'contact_merge' => array(),
);
