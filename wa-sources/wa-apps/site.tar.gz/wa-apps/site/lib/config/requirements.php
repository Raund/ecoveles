<?php
return array(
    'app.installer'=>array(
        'version'=>'>=1.1.0.18420',
        'strict'=>true,
    ),
);
//EOF