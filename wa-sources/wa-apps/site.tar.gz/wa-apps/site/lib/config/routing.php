<?php

return array(
    'login/' => 'login',
    'forgotpassword/' => 'forgotpassword',
    'signup/' => 'signup',
    '<url>' => 'frontend'
);