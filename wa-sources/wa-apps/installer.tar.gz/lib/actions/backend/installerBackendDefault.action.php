<?php
class installerBackendDefaultAction extends waViewAction
{
    public function execute()
    {
    }
}
