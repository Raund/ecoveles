<?php

return array(
	'app.installer' => array(
		'version' => '>=1.0.9.16910',
		'strict' => true
	),
);
