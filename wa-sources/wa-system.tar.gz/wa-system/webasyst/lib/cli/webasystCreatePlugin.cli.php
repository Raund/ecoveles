<?php

class webasystCreatePluginCli extends waCliController
{
    public function execute()
    {

    }
}