<?php

class waLogModel extends waModel
{
    protected $table = "wa_log";

}