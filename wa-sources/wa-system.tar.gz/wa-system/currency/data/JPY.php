<?php

return array(
    'code' => 'JPY',
    'sign' => '¥',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Japanese yen',
    'name' => array(
        'yen',
    ),
    'frac_name' => array(
    )
);