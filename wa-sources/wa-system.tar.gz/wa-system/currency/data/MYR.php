<?php

return array(
    'code' => 'MYR',
    'sign' => 'RM',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Malaysian ringgit',
    'name' => array(
        array('ringgit', 'ringgits'),
    ),
    'frac_name' => array(
        array('sen', 'sens'),
    )
);