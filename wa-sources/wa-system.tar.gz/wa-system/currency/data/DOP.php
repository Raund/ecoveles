<?php

return array(
    'code' => 'DOP',
    'sign' => '$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Dominican peso',
    'name' => array(
        array('peso', 'pesos'),
        'RD$',
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);